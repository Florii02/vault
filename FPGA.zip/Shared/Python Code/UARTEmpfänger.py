import serial
import time

def convertToDecimal(binary_string):
    temp = 0
    if binary_string[0] == '1':
        temp = -2

    for i in range(31):
        if binary_string[i+1] == '1':
            temp = temp + 2 ** (-i)

    return temp

def convertToComplex(binary_string):

    real = binary_string[0:32]
    imaginary = binary_string[32:64]

    real = convertToDecimal(real)
    imaginary = convertToDecimal(imaginary)

    c = complex(real, imaginary)
    return c

#initialsiere serielle Schnittstelle
ser = serial.Serial('COM8', 921600, timeout=1.5)  
time.sleep(2)

i = 0
current_number_bit_string = ""
last_data_time = time.time()

try:
    while True:

        if time.time() - last_data_time > 2:
            i = 0

        if ser.in_waiting:
            data = ser.read(ser.in_waiting)
            last_data_time = time.time()

            for byte in data:
                byte = format(byte, '08b')
                if byte == "00000001": # start byte
                    current_number_bit_string = ""

                elif byte == "10000001": # end byte
                    if len(current_number_bit_string) == 70:
                        current_number_bit_string = current_number_bit_string[0:64]

                        c = convertToComplex(current_number_bit_string)
                        if c.real > 0.001 or c.real < -0.001:
                            print(i, c)
                            pass
                        i += 1

                else:
                    current_number_bit_string += byte[0:7]

                

except KeyboardInterrupt:
    ser.close()