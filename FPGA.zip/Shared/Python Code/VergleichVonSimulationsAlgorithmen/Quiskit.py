from qiskit import QuantumCircuit, Aer, transpile, assemble
import time

#erstelle Quantenschaltkreis mit 14 Qubits

def QuiskitBenchmark(iterations, qubits=14, target=5):

    qc = QuantumCircuit(qubits)

    #
    for i in range(iterations):
        qc.h(target)



    # Benutze den Zustandsvektor-Simulator
    statevector_simulator = Aer.get_backend('statevector_simulator')



    transpiled_qc = transpile(qc, statevector_simulator)
    qobj = assemble(transpiled_qc)

    # Starte die Simulation und messe die Zeit
    start_time = time.time()
    result = statevector_simulator.run(qobj).result()
    end_time = time.time()

    # Hole den Zustandsvektor aus dem Ergebnis
    stateVector = result.get_statevector()
    
    # Ergebnis
    simulation_time = end_time - start_time
    return simulation_time/iterations, stateVector

