import numpy as np
import copy
import time

H = np.array([[complex(1/np.sqrt(2), 0),complex(1/np.sqrt(2), 0)],
              [complex(1/np.sqrt(2), 0),complex(-1/np.sqrt(2), 0)]])

I = np.array([[complex(1, 0),complex(0, 0)],
              [complex(0, 0),complex(1, 0)]])


class Qubit:
    def __init__(self, state = np.array([[complex(1, 0)],[complex(0, 0)]])):
        self.state = state

    def reset(self):
        self.state = np.array([[complex(1, 0)],[complex(0, 0)]])
        
    def __str__(self) -> str:
        return str(self.state)

class QuantumCircuit:
    
    def __init__(self, nQbits):
        self.nQbits = nQbits
        self.qubits = [Qubit() for _ in range(nQbits)]
        self.stateVector = self.qubits[0].state
        for i in range(1, nQbits):
            self.stateVector = np.kron(self.stateVector, self.qubits[i].state)
        self.stateVector = self.stateVector.astype(np.complex128)
    
    def H(self, target):
        target = self.nQbits - target - 1
        if target == 0:
            transformationMatrix = H
        else:
            transformationMatrix = I

        for i in range(1, self.nQbits):
            if i == target:
                transformationMatrix = np.kron(transformationMatrix, H)
            else:
                transformationMatrix = np.kron(transformationMatrix, I)
        self.stateVector = np.dot(transformationMatrix, self.stateVector)

    def __str__(self):
        return str(self.stateVector)




def transformationsmatrixBenchmark(iterations, qubits=14, target=5):
    qc = QuantumCircuit(qubits)
    start_time = time.time()
    for i in range(iterations):
        qc.H(target)
    end_time = time.time()

    simulation_time = end_time - start_time
    return simulation_time/iterations, qc.stateVector
    