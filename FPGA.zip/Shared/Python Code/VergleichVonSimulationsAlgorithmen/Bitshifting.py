import numpy as np
import copy
import time

H = np.array([[complex(1/np.sqrt(2), 0),complex(1/np.sqrt(2), 0)],
              [complex(1/np.sqrt(2), 0),complex(-1/np.sqrt(2), 0)]])


class Qubit:
    def __init__(self, state = np.array([[complex(1, 0)],[complex(0, 0)]])):
        self.state = state

    def reset(self):
        self.state = np.array([[complex(1, 0)],[complex(0, 0)]])
        
    def __str__(self) -> str:
        return str(self.state)

class QuantumCircuit:
    
    def __init__(self, nQbits):
        self.nQbits = nQbits
        self.qubits = [Qubit() for _ in range(nQbits)]
        self.stateVector = self.qubits[0].state
        for i in range(1, nQbits):
            self.stateVector = np.kron(self.stateVector, self.qubits[i].state)
        self.stateVector = self.stateVector.astype(np.complex128)
    
    def operation(self, matrix_2x2, target):
        target = self.nQbits - target - 1
        for i in range(0, 2**(self.nQbits-1)):
            zero_state, one_state = self._bitshifting(i, target)
           
            original_a = copy.deepcopy(self.stateVector[zero_state])
            original_b = copy.deepcopy(self.stateVector[one_state])

            new_a = (matrix_2x2[0][0] * original_a + matrix_2x2[0][1] * original_b)[0]
            new_b = (matrix_2x2[1][0] * original_a + matrix_2x2[1][1] * original_b)[0]

            self.stateVector[zero_state][0] = new_a
            self.stateVector[one_state][0] = new_b

    def _bitshifting(self, n, target):
        mask = (1 << target) - 1
        not_mask = ~mask

        nAndMask = n & mask
        nAndNotMask = n & not_mask
        nAndNotMask <<= 1
        result_0 = nAndMask | nAndNotMask

        x = (1 << target)
        result_1 = result_0 | x
        

        return result_0, result_1

    def __str__(self):
        return str(self.stateVector)

def bitshiftingBenchmark(iterations, qubits=14, target=5):
    qc = QuantumCircuit(qubits)
    start_time = time.time()
    for i in range(iterations):
        qc.operation(H, target)
    end_time = time.time()

    simulation_time = end_time - start_time
    return simulation_time/iterations, qc.stateVector
    
    
   
    
