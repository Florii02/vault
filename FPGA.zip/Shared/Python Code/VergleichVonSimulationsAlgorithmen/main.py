from Quiskit import QuiskitBenchmark
from Bitshifting import bitshiftingBenchmark
from Transformationsmatrix import transformationsmatrixBenchmark


#Der Benchmarks führen jeweils eine Hadamard-Operation auf das 5. Qubit aus, welches in einem 14-Qubit-System liegt. 
#Es sind mehrere Iterationen nötig, um eine aussagekräftige Zeitmessung zu erhalten.
#Die Zustandsvektoren sollten bei allen Benchmarks die gleichen sein, so lange die Anzahl der Iterationen bei allen Benchmarks gerade, oder bei allen ungerade ist. 

QuiskitBenchmarkTime, stateVector = QuiskitBenchmark(1000, 14, 5)
bitshiftingBenchmarkTime, stateVector = bitshiftingBenchmark(10, 14, 5)
transformationsmatrixBenchmarkTime, stateVector = transformationsmatrixBenchmark(5, 14, 5)




print("Quiskit Statevector: ", stateVector)
print("Bitshifting Statevector: ", stateVector)
print("Transformationsmatrix Statevector: ", stateVector)


print("Quiskit Benchmark Time: ", QuiskitBenchmarkTime, "s")
print("Bitshifting Benchmark Time: ", bitshiftingBenchmarkTime, "s")
print("Transformationsmatrix Benchmark Time: ", transformationsmatrixBenchmarkTime, "s")
